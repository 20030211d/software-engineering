const base = {
    get() {
        return {
            url : "http://localhost:8080/ssmt9pm0/",
            name: "ssmt9pm0",
            // 退出到首页链接
            indexUrl: ''
        };
    },
    getProjectName(){
        return {
            projectName: "校园卡管理系统"
        } 
    }
}
export default base
